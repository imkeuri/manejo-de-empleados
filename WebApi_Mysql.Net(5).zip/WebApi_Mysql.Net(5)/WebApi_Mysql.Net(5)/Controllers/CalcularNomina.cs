﻿namespace WebApi_Mysql.Net_5_.Controllers
{
    public class CalcularNomina
    {
    }
}
